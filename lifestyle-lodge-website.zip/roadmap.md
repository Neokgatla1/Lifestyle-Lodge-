# Lifestyle Lodge website
- [x] Review supplied property imagery and contact information.
- [x] Build hotel pages and interactions with real imagery.
- [x] Verify desktop/mobile presentation and booking inquiry flows.
- [ ] Wix live reservations, deposits, dining inventory, CRM and confirmations — blocked: connection declined; property setup required.
