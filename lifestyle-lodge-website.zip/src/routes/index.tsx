import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Accommodation, BookingBar, Distinction, ExperienceGrid, Gallery, Location, exterior } from "@/components/hotel";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Lifestyle Lodge | A Boutique Escape in Three Rivers" },
    { name: "description", content: "Discover Lifestyle Lodge in Three Rivers, Vereeniging: comfortable stays, poolside moments, dining and thoughtful hospitality in the Vaal Triangle." },
    { property: "og:title", content: "Lifestyle Lodge | A Boutique Escape in Three Rivers" },
    { property: "og:description", content: "Stay, unwind and gather at Lifestyle Lodge in Three Rivers, Vereeniging." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }), component: Home,
});
function Home() { return <main>
  <section className="relative min-h-[660px] h-[min(82vh,850px)] flex items-center bg-dark-surface text-background overflow-hidden"><img src={exterior.url} alt="Lifestyle Lodge and its pool in Three Rivers" className="absolute inset-0 w-full h-full object-cover object-center"/><div className="absolute inset-0 hero-shade"/><div className="relative z-10 max-w-[1500px] mx-auto w-full px-6 md:px-10 lg:px-16 pt-12"><p className="section-label text-accent mb-8">Lifestyle Lodge · Three Rivers, South Africa</p><h1 className="display text-[clamp(64px,9vw,140px)] max-w-[980px]">An Exclusive<br/><em className="font-normal">Sanctuary</em> in<br/>Three Rivers.</h1><p className="text-sm leading-7 max-w-[440px] mt-8 text-background/90">A tranquil place to retreat, gather and feel at home in the heart of the Vaal Triangle.</p><div className="flex flex-wrap gap-5 items-center mt-9"><Button variant="hotel" size="lg" className="h-13 px-7" asChild><Link to="/" hash="booking">Discover your stay <ArrowUpRight/></Link></Button><Link to="/experience" className="section-label border-b border-background pb-2 hover:text-accent">Explore the lodge</Link></div></div><div className="absolute bottom-10 right-8 md:right-16 z-10 hidden md:flex items-center gap-3 section-label text-background/80">Scroll to discover <ArrowDown size={15}/></div></section>
  <BookingBar />
  <section className="max-w-[1500px] mx-auto px-6 md:px-10 lg:px-16 pt-28 pb-4 grid md:grid-cols-[1fr_1.3fr] gap-8 md:gap-20"><p className="section-label text-accent pt-3">01 / A different pace</p><div><h2 className="display text-5xl md:text-[70px]">Some places simply make you <em>stay a little longer.</em></h2><p className="editorial-copy max-w-xl mt-8">Tucked into Three Rivers, Lifestyle Lodge is an invitation to slow down. Find your rhythm between comfortable rooms, afternoons by the water and evenings shared over a good meal.</p></div></section>
  <Accommodation />
  <ExperienceGrid />
  <Gallery />
  <Distinction />
  <Location />
</main> }
