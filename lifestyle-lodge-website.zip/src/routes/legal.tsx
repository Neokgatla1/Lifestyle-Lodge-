import { createFileRoute } from "@tanstack/react-router";

const T = "Legal Notice, Trademark & Privacy Policy | Lifestyle Lodge";
const D = "Privacy policy, POPIA compliance notice, trademark and ownership information for Lifestyle Lodge, Three Rivers.";

export const Route = createFileRoute("/legal")({
  head: () => ({ meta: [{ title: T }, { name: "description", content: D }, { property: "og:title", content: T }, { property: "og:description", content: D }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" }] }),
  component: LegalPage,
});

const Tel = () => <a href="tel:+27720495008" className="text-accent hover:underline">+27 72 049 5008</a>;
const Mail = () => <a href="mailto:neomaroo75@gmail.com" className="text-accent hover:underline">neomaroo75@gmail.com</a>;
const ADDR = "67 Poplar Street, Three Rivers, Vereeniging, Gauteng, 1935, South Africa";

function S({ n, title, children }: { n: number; title: string; children: React.ReactNode }) {
  return <section className="border-t border-border pt-10 mt-10"><p className="section-label text-accent mb-3">{String(n).padStart(2, "0")}</p><h2 className="font-display text-3xl md:text-4xl mb-5">{title}</h2><div className="editorial-copy space-y-4">{children}</div></section>;
}
function L({ items }: { items: string[] }) {
  return <ul className="space-y-2 list-disc pl-5">{items.map(i => { const [b, ...r] = i.split(": "); return <li key={i}>{r.length ? <><strong className="text-foreground">{b}:</strong> {r.join(": ")}</> : i}</li>; })}</ul>;
}

function LegalPage() {
  return <main className="py-20 md:py-28 px-5 md:px-10">
    <article className="max-w-[820px] mx-auto">
      <p className="section-label text-accent mb-5">Legal Notice, Trademark & Privacy Policy</p>
      <h1 className="display text-5xl md:text-7xl">Privacy Policy & POPIA Compliance Notice</h1>
      <dl className="mt-10 grid sm:grid-cols-[200px_1fr] gap-x-6 gap-y-3 text-xs leading-6">
        <dt className="section-label">Effective date</dt><dd>October 2026</dd>
        <dt className="section-label">Entity name</dt><dd>Lifestyle Lodge</dd>
        <dt className="section-label">Physical address</dt><dd>{ADDR}</dd>
        <dt className="section-label">Information Officer</dt><dd>Neo Kerileng Maroo (Software Engineer & IT Specialist)</dd>
        <dt className="section-label">Contact email</dt><dd><Mail /></dd>
        <dt className="section-label">Contact telephone</dt><dd><Tel /></dd>
      </dl>
      <S n={1} title="Introduction & Ownership Statement"><p>This website, including its visual design, user interface, brand assets, and underlying software codebase, is owned, engineered, and maintained by Neo Kerileng Maroo (Software Engineer & IT Specialist). Lifestyle Lodge ("we," "us," or "our") respects your right to privacy and is committed to protecting your personal information. This Privacy Policy outlines how we collect, use, process, store, and safeguard your personal data in accordance with the Protection of Personal Information Act, No. 4 of 2013 ("POPIA") and the Electronic Communications and Transactions Act, No. 25 of 2002 ("ECTA") of South Africa.</p></S>
      <S n={2} title="Intellectual Property & Trademarks"><p>Lifestyle Lodge and associated custom web assets are proprietary software and design elements protected under the South African Copyright Act 98 of 1978 and Trade Marks Act 194 of 1993. All rights reserved. Unauthorized duplication or reproduction is strictly prohibited.</p></S>
      <S n={3} title="Personal Information We Collect"><p>In operating our boutique hospitality lodge and web booking channels, we may collect and process:</p><L items={["Identity Data: Full names, identity/passport numbers, nationality, and title.", "Contact Data: Email addresses, telephone numbers, cellular numbers (including WhatsApp contact details), and physical addresses.", "Booking & Stay Details: Arrival/departure dates, room preferences, and guest count.", "Financial & Transactional Data: Proof of payment or bank transfer details required to confirm bookings.", "Technical Data: IP addresses, browser types, and session metrics gathered automatically during navigation."]} /></S>
      <S n={4} title="Lawful Basis and Purpose of Processing"><p>Your data is processed solely to:</p><L items={["Process booking enquiries and confirm reservations via email or WhatsApp.", "Deliver hospitality services and accommodate special guest requests.", "Comply with South African statutory regulations (guest registers, tax, and accounting standards)."]} /></S>
      <S n={5} title="WhatsApp Communication"><p>When initiating an enquiry or booking via our interactive WhatsApp link, you consent to communicating with our management and Information Officer over WhatsApp. Messages are end-to-end encrypted and used exclusively for stay verification.</p></S>
      <S n={6} title="Data Security & Storage"><p>Communications are secured using standard SSL/TLS encryption. Personal information is retained only for as long as required by South African law (e.g., retaining accounting records for 5 years) and is securely destroyed thereafter.</p></S>
      <S n={7} title="Your Rights Under POPIA"><p>Under POPIA, you have the right to request access to your personal data, request corrections or updates, or object to data processing by contacting our Information Officer.</p></S>
      <S n={8} title="Information Officer & Contact Details">
        <p><strong className="text-foreground">Information Officer:</strong> Neo Kerileng Maroo<br /><strong className="text-foreground">Role:</strong> Software Engineer & IT Specialist<br /><strong className="text-foreground">Address:</strong> {ADDR}<br /><strong className="text-foreground">Email:</strong> <Mail /><br /><strong className="text-foreground">Telephone:</strong> <Tel /></p>
        <p className="pt-4"><strong className="text-foreground">South African Information Regulator Enquiries:</strong><br />Website: <a href="https://inforegulator.org.za" target="_blank" rel="noopener noreferrer" className="text-accent hover:underline">https://inforegulator.org.za</a><br />Email: <a href="mailto:POPIAComplaints@inforegulator.org.za" className="text-accent hover:underline">POPIAComplaints@inforegulator.org.za</a></p>
      </S>
    </article>
  </main>;
}
