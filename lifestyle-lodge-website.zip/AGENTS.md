<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- The hotel website uses uploaded property imagery through Lovable Assets pointers, so media can be served without committing original uploads.
- Reservation, dining, event and concierge actions open direct WhatsApp inquiries until a verified booking provider connection exists, so the site does not imply real-time availability or payment processing.
